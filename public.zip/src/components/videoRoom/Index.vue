<template>
  <div class="liveRoomVideo">
    <div class="top">
      <div class="anchor"></div>
      <div class="hot"></div>
    </div>
    <div class="video-container" ref="video">
      <!-- 视频 -->
      <div class="video-containers">
        <!-- video.js -->
        <video
          id="zxc"
          preload="auto"
          playsinline
          webkit-playsinline
          width="414" height="270"
        >
          <!-- <source  /> -->
        </video>
      </div>
      <div class="videoBottom">
        <div class="start">
          <!-- <div
            class="iconfont icon-shipin"
            @click="startVideoPlayback"
            style="color: #fff; font-size: 25px"
          ></div> -->
        </div>
      </div>
    </div>
    <div class="bottom"></div>
  </div>
</template>


<script>
// import videojs from "video.js";
// import "video.js/dist/video-js.css";
import TCPlayer from "tcplayer.js";
import "tcplayer.js/dist/tcplayer.min.css";

export default {
  name: "videoRoom",
  data() {
    return {
      player: null, // 初始化播放器实例
      anchroPlayer: null,
      isLoading: true, //视频加载
      videoUrl: '',
    };
  },

  mounted() {
    var player = TCPlayer('zxc', {
      sources: [{
      src: 'webrtc://play.dabayuu.com/OBS/clubcamisole',
    }],

    });
    // player.src("webrtc://play.dabayuu.com/OBS/clubcamisole");
  },

  methods: {
    // startVideoPlayback() {
    //   try {
    //     const videoElement = this.$refs.videoElement;
    //     this.player = videojs(videoElement, {
    //       fluid: true,
    //     });

    //     this.player.src({
    //       src: this.videoUrl,
    //       type: "application/x-mpegURL",
    //     });

    //     // 视频自动播放
    //     this.player.play();
    //   } catch (error) {
    //     console.log(error);
    //   }
    // },
    // //loading加载
    // handleVideo() {
    //   this.isLoading = this.$refs.videoElement.paused;
    // },
  },

  destroyed() {
    // 销毁播放器实例
    if (this.player) {
      this.player.dispose();
    }
  },
};
</script>

<style lang="scss" scoped>
// @import "./Index.scss";
</style>
